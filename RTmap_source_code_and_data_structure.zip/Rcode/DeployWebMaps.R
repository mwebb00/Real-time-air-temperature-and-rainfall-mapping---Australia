########################################################################
####DEPLOY INTERPOLATED AIR TEMPERATURE SURFACE TO WEBMAP USING SHINY###
########################################################################

#AUTHOR: M.Webb, USYD
#PURPOSE: A nationwide temperature and rainfall map is deployed to a shiny web app based on surfaces produced from the Real time mapping code.

###INPUT PARAMETERS###################################################################################################################################

#SHINY APP SETTINGS#
#Shiny_url:
Shiny_url<-"###.#.###.##"
#Shiny_port:
Shiny_port<-3838
#Import mapping code output - Define 'shiny_app_data.RData' location:
rdat<-load("/mnt/Mapping_system_DATAMODEL/INTERMEDIATE_LUT/shiny_app_data.RData") 

###SCRIPT STARTS HERE##################################################################################################################################
print("Initiating script...")
#Geoserver and shiny must be operating in order for the web application to be deploy 
if(GEOSERVER=="y"){
  #Additionally, a minimum of 6 air temperature & rainfall maps must exist in GeoServer before Web application can be deployed
  num_outputs<-na.omit(tifnames_df)
  if(length(num_outputs)>=6){
    #Import relevant libraries
    if(require("rgdal")){
      print("rgdal is loaded correctly")
    } else {
      print("trying to install rgdal")
      install.packages("rgdal")
      if(require("rgdal")){
        print("rgdal installed and loaded")
      } else {
        stop("could not install rgdal")
      }
    }
    if(require("raster")){
      print("raster is loaded correctly")
    } else {
      print("trying to install raster")
      install.packages("raster")
      if(require("raster")){
        print("raster installed and loaded")
      } else {
        stop("could not install raster")
      }
    }
    if(require("leaflet")){
      print("leaflet is loaded correctly")
    } else {
      print("trying to install leaflet")
      install.packages("leaflet")
      if(require("leaflet")){
        print("leaflet installed and loaded")
      } else {
        stop("could not install leaflet")
      }
    }
    if(require("htmlwidgets")){
      print("htmlwidgets is loaded correctly")
    } else {
      print("trying to install htmlwidgets")
      install.packages("htmlwidgets")
      if(require("htmlwidgets")){
        print("htmlwidgets installed and loaded")
      } else {
        stop("could not install htmlwidgets")
      }
    }
    if(require("leaflet.extras")){
      print("leaflet.extras is loaded correctly")
    } else {
      print("trying to install leaflet.extras")
      install.packages("leaflet.extras")
      if(require("leaflet.extras")){
        print("leaflet.extras installed and loaded")
      } else {
        stop("could not install leaflet.extras")
      }
    }
    if(require("leaflet.esri")){
      print("leaflet.esri is loaded correctly")
    } else {
      print("trying to install leaflet.esri")
      install.packages("leaflet.esri")
      if(require("leaflet.esri")){
        print("leaflet.esri installed and loaded")
      } else {
        stop("could not install leaflet.esri")
      }
    }
    if(require("shiny")){
      print("shiny is loaded correctly")
    } else {
      print("trying to install shiny")
      install.packages("shiny")
      if(require("shiny")){
        print("shiny installed and loaded")
      } else {
        stop("could not install shiny")
      }
    }
    
    #Define AM/PM strings for display
    HRi<-as.numeric(substr(tifnames_df[1],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr1<-HRi
    
    HRi<-as.numeric(substr(tifnames_df[2],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr2<-HRi
    
    HRi<-as.numeric(substr(tifnames_df[3],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr3<-HRi
    
    HRi<-as.numeric(substr(tifnames_df[4],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr4<-HRi
    
    HRi<-as.numeric(substr(tifnames_df[5],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr5<-HRi
    
    HRi<-as.numeric(substr(tifnames_df[6],9,12))
    if(HRi==0){HRi<-"12:00AM"};if(HRi==30){HRi<-paste0(HRi<-"12:30AM")};if(HRi==100){HRi<-paste0(HRi<-"1:00AM")};if(HRi==130){HRi<-paste0(HRi<-"1:30AM")};
    if(HRi==200){HRi<-paste0(HRi<-"2:00AM")};if(HRi==230){HRi<-paste0(HRi<-"2:30AM")};if(HRi==300){HRi<-paste0(HRi<-"3:00AM")};if(HRi==330){HRi<-paste0(HRi<-"3:30AM")};
    if(HRi==400){HRi<-paste0(HRi<-"4:00AM")};if(HRi==430){HRi<-paste0(HRi<-"4:30AM")};if(HRi==500){HRi<-paste0(HRi<-"5:00AM")};if(HRi==530){HRi<-paste0(HRi<-"5:30AM")};
    if(HRi==600){HRi<-paste0(HRi<-"6:00AM")};if(HRi==630){HRi<-paste0(HRi<-"6:30AM")};if(HRi==700){HRi<-paste0(HRi<-"7:00AM")};if(HRi==730){HRi<-paste0(HRi<-"7:30AM")};
    if(HRi==800){HRi<-paste0(HRi<-"8:00AM")};if(HRi==830){HRi<-paste0(HRi<-"8:30AM")};if(HRi==900){HRi<-paste0(HRi<-"9:00AM")};if(HRi==930){HRi<-paste0(HRi<-"9:30AM")};
    if(HRi==1000){HRi<-paste0(HRi<-"10:00AM")};if(HRi==1030){HRi<-paste0(HRi<-"10:30AM")};if(HRi==1100){HRi<-paste0(HRi<-"11:00AM")};if(HRi==1130){HRi<-paste0(HRi<-"11:30AM")};
    if(HRi==1200){HRi<-"12:00PM"};if(HRi==1230){HRi<-paste0(HRi<-"12:30PM")};if(HRi==1300){HRi<-paste0(HRi<-"1:00PM")};if(HRi==1330){HRi<-paste0(HRi<-"1:30PM")};
    if(HRi==1400){HRi<-paste0(HRi<-"2:00PM")};if(HRi==1430){HRi<-paste0(HRi<-"2:30PM")};if(HRi==1500){HRi<-paste0(HRi<-"3:00PM")};if(HRi==1530){HRi<-paste0(HRi<-"3:30PM")};
    if(HRi==1600){HRi<-paste0(HRi<-"4:00PM")};if(HRi==1630){HRi<-paste0(HRi<-"4:30PM")};if(HRi==1700){HRi<-paste0(HRi<-"5:00PM")};if(HRi==1730){HRi<-paste0(HRi<-"5:30PM")};
    if(HRi==1800){HRi<-paste0(HRi<-"6:00PM")};if(HRi==1830){HRi<-paste0(HRi<-"6:30PM")};if(HRi==1900){HRi<-paste0(HRi<-"7:00PM")};if(HRi==1930){HRi<-paste0(HRi<-"7:30PM")};
    if(HRi==2000){HRi<-paste0(HRi<-"8:00PM")};if(HRi==2030){HRi<-paste0(HRi<-"8:30PM")};if(HRi==2100){HRi<-paste0(HRi<-"9:00PM")};if(HRi==2130){HRi<-paste0(HRi<-"9:30PM")};
    if(HRi==2200){HRi<-paste0(HRi<-"10:00PM")};if(HRi==2230){HRi<-paste0(HRi<-"10:30PM")};if(HRi==2300){HRi<-paste0(HRi<-"11:00PM")};if(HRi==2330){HRi<-paste0(HRi<-"11:30PM")}
    tifnames_df_hr6<-HRi
    
    #Create the Shiny App according to timezone AEDT or AEST
    system("sudo systemctl stop shiny-server")
    if(AET_str=="AEDT"){#20191025
      
      setwd(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam,"tif"))
      r1<- raster(paste0("TempPrediction_",tifnames_df[1],"AEDT.tif"))
      r2<- raster(paste0("TempPrediction_",tifnames_df[2],"AEDT.tif"))
      r3<- raster(paste0("TempPrediction_",tifnames_df[3],"AEDT.tif"))
      r4<- raster(paste0("TempPrediction_",tifnames_df[4],"AEDT.tif"))
      r5<- raster(paste0("TempPrediction_",tifnames_df[5],"AEDT.tif"))
      r6<- raster(paste0("TempPrediction_",tifnames_df[6],"AEDT.tif"))
      
      setwd(file.path(OUTPUT_RainfallMapping_LIVE,SareaNam,"tif"))
      r7<- raster(paste0("RainPrediction_",tifnames_df[1],"AEDT.tif"))
      r8<- raster(paste0("RainPrediction_",tifnames_df[2],"AEDT.tif"))
      r9<- raster(paste0("RainPrediction_",tifnames_df[3],"AEDT.tif"))
      r10<- raster(paste0("RainPrediction_",tifnames_df[4],"AEDT.tif"))
      r11<- raster(paste0("RainPrediction_",tifnames_df[5],"AEDT.tif"))
      r12<- raster(paste0("RainPrediction_",tifnames_df[6],"AEDT.tif"))
      
      ui <- fluidPage(
        leafletOutput("tempmap", height = "95vh")
      )
      
      server <- function(input,output,session){
        output$tempmap <- renderLeaflet({
          m<-leaflet(data = BOMAWS_temps) %>% setView(134, -30, zoom = 5) %>%
            addMarkers(~Long, ~Lat, popup = ~as.character(paste0("<a href=",URL,">Click to access observations</a>")), label = ~as.character(paste0(Temperature,"�C, ",Rain,"mm [",HR,", ",DY,"/",MN,"/",YR,"]")), labelOptions(noHide = TRUE),group="BoM weather stations") %>%
            addTiles(group="Topo Map Default") %>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[1],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr1),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[2],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr2),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[3],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr3),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[4],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr4),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[5],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr5),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[6],"AEDT"),
              group = paste0("Temp (�C) for ",tifnames_df_hr6),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[1],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr1),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[2],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr2),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[3],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr3),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[4],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr4),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[5],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr5),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[6],"AEDT"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr6),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",0,"AEDT"),
              group = "Topo Map",
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addProviderTiles(providers$Esri.WorldImagery, group = "Satellite Imagery") %>%
            addLegend(pal = temppal, values = temprg,title = paste0    ("Air Temperature (�C)"), position = "bottomleft") %>%
            addLegend(pal = rainpal, values = rainrg,title = paste0    ("Rain (mm) since 9am"), position = "bottomleft") %>%
            addLegend("topright", labels = paste0("> Current to ",HR," AEDT, ",DY,"/",MN,"/",YR),title = "AIR TEMPERATURE & RAINFALL MAP 'LIVE', AUSTRALIA", colors = "clear") %>%
            addLayersControl(
              baseGroups = c(paste0("Temp (�C) for ",tifnames_df_hr1),paste0("Temp (�C) for ",tifnames_df_hr2),paste0("Temp (�C) for ",tifnames_df_hr3),paste0("Temp (�C) for ",tifnames_df_hr4),paste0("Temp (�C) for ",tifnames_df_hr5),paste0("Temp (�C) for ",tifnames_df_hr6),paste0("Rain (mm) since 9am to ",tifnames_df_hr1),paste0("Rain (mm) since 9am to ",tifnames_df_hr2),paste0("Rain (mm) since 9am to ",tifnames_df_hr3),paste0("Rain (mm) since 9am to ",tifnames_df_hr4),paste0("Rain (mm) since 9am to ",tifnames_df_hr5),paste0("Rain (mm) since 9am to ",tifnames_df_hr6),"Topo Map","Satellite Imagery"),
              overlayGroups = "BoM weather stations",
              position = 'topright',
              options = layersControlOptions(collapsed = F)) %>%
            hideGroup("BoM weather stations")
        })
        ## Observe mouse clicks and add circles
        observeEvent(input$tempmap_click, {
          click <- input$tempmap_click
          clat <- click$lat
          clng <- click$lng
          
          coord<-data.frame(cbind(clng,clat));colnames(coord)<-c("lon", "lat")
          coordinates(coord) <- c("lon", "lat")
          proj4string(coord) <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")
          coord_proj <- spTransform(coord, "+proj=utm +zone=55 +south +ellps=WGS84 +units=m +no_defs")
          ext1<-extract(r1,coord_proj)
          ext2<-extract(r2,coord_proj)
          ext3<-extract(r3,coord_proj)
          ext4<-extract(r4,coord_proj)
          ext5<-extract(r5,coord_proj)
          ext6<-extract(r6,coord_proj)
          
          ext7<-extract(r7,coord_proj)
          ext8<-extract(r8,coord_proj)
          ext9<-extract(r9,coord_proj)
          ext10<-extract(r10,coord_proj)
          ext11<-extract(r11,coord_proj)
          ext12<-extract(r12,coord_proj)
          
          print(click)
          r1_str<-paste0("",tifnames_df_hr1," = ",round(ext1,1),"�C, ",round(ext7,1),"mm")
          r2_str<-paste0("",tifnames_df_hr2," = ",round(ext2,1),"�C, ",round(ext8,1),"mm")
          r3_str<-paste0("",tifnames_df_hr3," = ",round(ext3,1),"�C, ",round(ext9,1),"mm")
          r4_str<-paste0("",tifnames_df_hr4," = ",round(ext4,1),"�C, ",round(ext10,1),"mm")
          r5_str<-paste0("",tifnames_df_hr5," = ",round(ext5,1),"�C, ",round(ext11,1),"mm")
          r6_str<-paste0("",tifnames_df_hr6," = ",round(ext6,1),"�C, ",round(ext12,1),"mm")
          
          proxy <- leafletProxy("tempmap")
          proxy %>% clearPopups() %>%
            addPopups(lat=clat, lng=clng, popup=paste(r1_str, "<br>",
                                                      r2_str, "<br>",
                                                      r3_str, "<br>",
                                                      r4_str, "<br>",
                                                      r5_str, "<br>",
                                                      r6_str, "<br>"))
        })
      }
      runApp(list(ui = ui, server = server),host=Shiny_url,port=Shiny_port, launch.browser = F)
    }
    
    if(AET_str=="AEST"){#20191025
      
      setwd(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam,"tif"))
      r1<- raster(paste0("TempPrediction_",tifnames_df[1],"AEST.tif"))
      r2<- raster(paste0("TempPrediction_",tifnames_df[2],"AEST.tif"))
      r3<- raster(paste0("TempPrediction_",tifnames_df[3],"AEST.tif"))
      r4<- raster(paste0("TempPrediction_",tifnames_df[4],"AEST.tif"))
      r5<- raster(paste0("TempPrediction_",tifnames_df[5],"AEST.tif"))
      r6<- raster(paste0("TempPrediction_",tifnames_df[6],"AEST.tif"))
      
      setwd(file.path(OUTPUT_RainfallMapping_LIVE,SareaNam,"tif"))
      r7<- raster(paste0("RainPrediction_",tifnames_df[1],"AEST.tif"))
      r8<- raster(paste0("RainPrediction_",tifnames_df[2],"AEST.tif"))
      r9<- raster(paste0("RainPrediction_",tifnames_df[3],"AEST.tif"))
      r10<- raster(paste0("RainPrediction_",tifnames_df[4],"AEST.tif"))
      r11<- raster(paste0("RainPrediction_",tifnames_df[5],"AEST.tif"))
      r12<- raster(paste0("RainPrediction_",tifnames_df[6],"AEST.tif"))
      
      ui <- fluidPage(
        leafletOutput("tempmap", height = "95vh")
      )
      
      server <- function(input,output,session){
        output$tempmap <- renderLeaflet({
          m<-leaflet(data = BOMAWS_temps) %>% setView(134, -30, zoom = 5) %>%
            addMarkers(~Long, ~Lat, popup = ~as.character(paste0("<a href=",URL,">Click to access observations</a>")), label = ~as.character(paste0(Temperature,"�C, ",Rain,"mm [",HR,", ",DY,"/",MN,"/",YR,"]")), labelOptions(noHide = TRUE),group="BoM weather stations") %>%
            addTiles(group="Topo Map Default") %>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[1],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr1),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[2],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr2),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[3],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr3),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[4],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr4),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[5],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr5),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",tifnames_df[6],"AEST"),
              group = paste0("Temp (�C) for ",tifnames_df_hr6),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[1],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr1),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[2],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr2),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[3],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr3),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[4],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr4),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[5],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr5),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name2,"/wms?service=WMS"),
              layers = paste0("RainPrediction_",tifnames_df[6],"AEST"),
              group = paste0("Rain (mm) since 9am to ",tifnames_df_hr6),
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addWMSTiles(
              paste0(GeoServer_url,"/",GeoServer_workspace_name,"/wms?service=WMS"),
              layers = paste0("TempPrediction_",0,"AEST"),
              group = "Topo Map",
              options = WMSTileOptions(format = "image/png", transparent = TRUE, version ="1.3.0",opacity = 0.7))%>%
            addProviderTiles(providers$Esri.WorldImagery, group = "Satellite Imagery") %>%
            addLegend(pal = temppal, values = temprg,title = paste0    ("Air Temperature (�C)"), position = "bottomleft") %>%
            addLegend(pal = rainpal, values = rainrg,title = paste0    ("Rain (mm) since 9am"), position = "bottomleft") %>%
            addLegend("topright", labels = paste0("> Current to ",HR," AEST, ",DY,"/",MN,"/",YR),title = "AIR TEMPERATURE & RAINFALL MAP 'LIVE', AUSTRALIA", colors = "clear") %>%
            addLayersControl(
              baseGroups = c(paste0("Temp (�C) for ",tifnames_df_hr1),paste0("Temp (�C) for ",tifnames_df_hr2),paste0("Temp (�C) for ",tifnames_df_hr3),paste0("Temp (�C) for ",tifnames_df_hr4),paste0("Temp (�C) for ",tifnames_df_hr5),paste0("Temp (�C) for ",tifnames_df_hr6),paste0("Rain (mm) since 9am to ",tifnames_df_hr1),paste0("Rain (mm) since 9am to ",tifnames_df_hr2),paste0("Rain (mm) since 9am to ",tifnames_df_hr3),paste0("Rain (mm) since 9am to ",tifnames_df_hr4),paste0("Rain (mm) since 9am to ",tifnames_df_hr5),paste0("Rain (mm) since 9am to ",tifnames_df_hr6),"Topo Map","Satellite Imagery"),
              overlayGroups = "BoM weather stations",
              position = 'topright',
              options = layersControlOptions(collapsed = F)) %>%
            hideGroup("BoM weather stations")
        })
        ## Observe mouse clicks and add circles
        observeEvent(input$tempmap_click, {
          click <- input$tempmap_click
          clat <- click$lat
          clng <- click$lng
          
          coord<-data.frame(cbind(clng,clat));colnames(coord)<-c("lon", "lat")
          coordinates(coord) <- c("lon", "lat")
          proj4string(coord) <- CRS("+proj=longlat +datum=WGS84 +ellps=WGS84 +towgs84=0,0,0")
          coord_proj <- spTransform(coord, "+proj=utm +zone=55 +south +ellps=WGS84 +units=m +no_defs")
          ext1<-extract(r1,coord_proj)
          ext2<-extract(r2,coord_proj)
          ext3<-extract(r3,coord_proj)
          ext4<-extract(r4,coord_proj)
          ext5<-extract(r5,coord_proj)
          ext6<-extract(r6,coord_proj)
          
          ext7<-extract(r7,coord_proj)
          ext8<-extract(r8,coord_proj)
          ext9<-extract(r9,coord_proj)
          ext10<-extract(r10,coord_proj)
          ext11<-extract(r11,coord_proj)
          ext12<-extract(r12,coord_proj)
          
          print(click)
          r1_str<-paste0("",tifnames_df_hr1," = ",round(ext1,1),"�C, ",round(ext7,1),"mm")
          r2_str<-paste0("",tifnames_df_hr2," = ",round(ext2,1),"�C, ",round(ext8,1),"mm")
          r3_str<-paste0("",tifnames_df_hr3," = ",round(ext3,1),"�C, ",round(ext9,1),"mm")
          r4_str<-paste0("",tifnames_df_hr4," = ",round(ext4,1),"�C, ",round(ext10,1),"mm")
          r5_str<-paste0("",tifnames_df_hr5," = ",round(ext5,1),"�C, ",round(ext11,1),"mm")
          r6_str<-paste0("",tifnames_df_hr6," = ",round(ext6,1),"�C, ",round(ext12,1),"mm")
          
          proxy <- leafletProxy("tempmap")
          proxy %>% clearPopups() %>%
            addPopups(lat=clat, lng=clng, popup=paste(r1_str, "<br>",
                                                      r2_str, "<br>",
                                                      r3_str, "<br>",
                                                      r4_str, "<br>",
                                                      r5_str, "<br>",
                                                      r6_str, "<br>"))
        })
      }
      runApp(list(ui = ui, server = server),host=Shiny_url,port=Shiny_port, launch.browser = F)
    }
  }else{print("Insufficent outputs on GeoServer, shiny application cannot launch")}
}else{print("Geoserver and shiny not configured, shiny application cannot launch")}





