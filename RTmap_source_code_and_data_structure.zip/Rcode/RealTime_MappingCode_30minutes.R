##############################################################
####PRODUCE NATIONWIDE TEMPERATURE MAP FOR EVERY HOUR @ 30min#
##############################################################

#AUTHOR: M.Webb, USYD
#PURPOSE: A nationwide air temperature and rainfall map is produced based from 'near real-time' BoM AWS data relevant for observations at 00 minutes (past the hour of interest)

###INPUT PARAMETERS###################################################################################################################################

#Define root directory of the Mapping_system_DATAMODEL
ROOT_DIR<-"/Mapping_system_DATAMODEL"

###GEOSERVER AND SHINY SETTINGS###
#If both are installed and operating nominate "y", else "n".
GEOSERVER<- "y"
#IF GEOSERVER is "y" define the following settings:
if(GEOSERVER=="y"){
  #Geoserver Username:
  UN<-"#####"
  #Geoserver password:
  PW<-######
  #URL
  GeoServer_url<-"http://###.#.###.##:####/geoserver"
  #Workspace name for temperature:
  GeoServer_workspace_name<-"TempPred" #NB: Workspace must be created manually within GeoServer
  #Geoserver style name for temperature:
  Style_name<-"Air_temperature_degC" #NB: Style must be created manually within GeoServer
  #Workspace name for rainfall:
  GeoServer_workspace_name2<-"RainPred" #NB: Workspace must be created manually within GeoServer
  #Geoserver style name for rainfall:
  Style_name2<-"Rainfall_mm" #NB: Style must be created manually within GeoServer
  #Define coordinate system
  CoordSysCode<-"EPSG:3112"
}

### ENSURE WORKING DIRECTORY #########################################################################################################################
setwd(switch(.Platform$OS.type, unix = ROOT_DIR, windows = ROOT_DIR))
if (!file.exists("INTERMEDIATE_CovariateData")) stop("Wrong working directory folder! Please set the working directory to the project root folder and try again.")

INPUT_StudyAreas<-                      file.path(getwd(),"INPUT_StudyAreas")
INTERMEDIATE_LUT<-                      file.path(getwd(),"INTERMEDIATE_LUT")
INTERMEDIATE_CovariateData<-            file.path(getwd(),"INTERMEDIATE_CovariateData")
INTERMEDIATE_CovariateData_BOMLOG<-     file.path(getwd(),"INTERMEDIATE_CovariateData","BOMLOG")
INTERMEDIATE_CovariateData_AWS<-        file.path(getwd(),"INTERMEDIATE_CovariateData","AWS")
INTERMEDIATE_CovariateData_TAS<-        file.path(getwd(),"INTERMEDIATE_CovariateData","TAS")
INTERMEDIATE_CovariateData_StudyAreas<- file.path(getwd(),"INTERMEDIATE_CovariateData","StudyAreas")
INTERMEDIATE_CalibrationFiles_ADFD<-    file.path(getwd(),"INTERMEDIATE_CalibrationFiles_ADFD")
OUTPUT_TemperatureMapping_LIVE<-        file.path(getwd(),"OUTPUT_TemperatureMapping_LIVE")
OUTPUT_RainfallMapping_LIVE<-           file.path(getwd(),"OUTPUT_RainfallMapping_LIVE")
ROOT_DIR<-                              file.path(getwd())

###SCRIPT STARTS HERE######################################################################################################################################
print("Initiating script...")
t_rn<-substr(as.POSIXlt(Sys.time(), "GMT"), 15, 16);options(scipen=999)#remove scientific notation
###Install/load the required R packages###
if(require("httr")){
  print("httr is loaded correctly")
} else {
  print("trying to install httr")
  install.packages("httr")
  if(require("httr")){
    print("httr installed and loaded")
  } else {
    stop("could not install httr")
  }
}
if(require("RNetCDF")){
  print("RNetCDF is loaded correctly")
} else {
  print("trying to install RNetCDF")
  install.packages("RNetCDF")
  if(require("RNetCDF")){
    print("RNetCDF installed and loaded")
  } else {
    stop("could not install RNetCDF")
  }
}
if(require("ncdf4")){
  print("ncdf4 is loaded correctly")
} else {
  print("trying to install ncdf4")
  install.packages("ncdf4")
  if(require("ncdf4")){
    print("ncdf4 installed and loaded")
  } else {
    stop("could not install ncdf4")
  }
}
if(require("epiR")){
  print("epiR is loaded correctly")
} else {
  print("trying to install epiR")
  install.packages("epiR")
  if(require("epiR")){
    print("epiR installed and loaded")
  } else {
    stop("could not install epiR")
  }
}
if(require("plyr")){
  print("plyr is loaded correctly")
} else {
  print("trying to install plyr")
  install.packages("plyr")
  if(require("plyr")){
    print("plyr installed and loaded")
  } else {
    stop("could not install plyr")
  }
}
if(require("gstat")){
  print("gstat is loaded correctly")
} else {
  print("trying to install gstat")
  install.packages("gstat")
  if(require("gstat")){
    print("gstat installed and loaded")
  } else {
    stop("could not install gstat")
  }
}
if(require("sp")){
  print("sp is loaded correctly")
} else {
  print("trying to install sp")
  install.packages("sp")
  if(require("sp")){
    print("sp installed and loaded")
  } else {
    stop("could not install sp")
  }
}
if(require("automap")){
  print("automap is loaded correctly")
} else {
  print("trying to install automap")
  install.packages("automap")
  if(require("automap")){
    print("automap installed and loaded")
  } else {
    stop("could not install automap")
  }
}
if(require("rgdal")){
  print("rgdal is loaded correctly")
} else {
  print("trying to install rgdal")
  install.packages("rgdal")
  if(require("rgdal")){
    print("rgdal installed and loaded")
  } else {
    stop("could not install rgdal")
  }
}
if(require("raster")){
  print("raster is loaded correctly")
} else {
  print("trying to install raster")
  install.packages("raster")
  if(require("raster")){
    print("raster installed and loaded")
  } else {
    stop("could not install raster")
  }
}
if(require("MASS")){
  print("MASS is loaded correctly")
} else {
  print("trying to install MASS")
  install.packages("MASS")
  if(require("MASS")){
    print("MASS installed and loaded")
  } else {
    stop("could not install MASS")
  }
}
if(require("doParallel")){
  print("doParallel is loaded correctly")
} else {
  print("trying to install doParallel")
  install.packages("doParallel")
  if(require("doParallel")){
    print("doParallel installed and loaded")
  } else {
    stop("could not install doParallel")
  }
}
if(require("foreach")){
  print("foreach is loaded correctly")
} else {
  print("trying to install foreach")
  install.packages("foreach")
  if(require("foreach")){
    print("foreach installed and loaded")
  } else {
    stop("could not install foreach")
  }
}
if(require("snow")){
  print("snow is loaded correctly")
} else {
  print("trying to install snow")
  install.packages("snow")
  if(require("snow")){
    print("snow installed and loaded")
  } else {
    stop("could not install snow")
  }
}
if(require("Cubist")){
  print("Cubist is loaded correctly")
} else {
  print("trying to install Cubist")
  install.packages("Cubist")
  if(require("Cubist")){
    print("Cubist installed and loaded")
  } else {
    stop("could not install Cubist")
  }
}
if(require("fields")){
  print("fields is loaded correctly")
} else {
  print("trying to install fields")
  install.packages("fields")
  if(require("fields")){
    print("fields installed and loaded")
  } else {
    stop("could not install fields")
  }
}

#########################################################################################################################################################################################################################
###Import BoM temperature data##########################################################################################################################################################################################
#########################################################################################################################################################################################################################
print("Importing BoM temperature data...")
#Define local time versus GMT
GMT<-as.POSIXct(format(Sys.time(), tz="GMT",usetz=TRUE));TasLT<-as.POSIXct(format(Sys.time(), tz="Australia/Tasmania",usetz=TRUE));TasLT1hr<-TasLT-(60*60)
td<-round(as.numeric(TasLT - GMT),0)#Time difference in hours between GMT and local time
BOMDATE_AET<-as.numeric(paste0(substr(TasLT, 1, 4),substr(TasLT, 6, 7),substr(TasLT, 9, 10),ifelse(substr(TasLT, 12, 13)=="","00",substr(TasLT, 12, 13)),30))
BOMDATE_AET1hr<-as.numeric(paste0(substr(TasLT1hr, 1, 4),substr(TasLT1hr, 6, 7),substr(TasLT1hr, 9, 10),ifelse(substr(TasLT1hr, 12, 13)=="","00",substr(TasLT1hr, 12, 13))))
ifelse(td==10,AET_str<-"AEST",AET_str<-"AEDT")
BOMDATE_GMT<-as.numeric(paste0(substr(GMT, 1, 4),substr(GMT, 6, 7),substr(GMT, 9, 10),ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)),30))

BOMDATE_AET_30<-as.POSIXct(format(paste0(substr(TasLT, 1, 4),"-",substr(TasLT, 6, 7),"-",substr(TasLT, 9, 10)," ",ifelse(substr(TasLT, 12, 13)=="","00",substr(TasLT, 12, 13)),":30"), tz="GMT",usetz=TRUE))-(60*30)
BOMDATE_AET_30<-as.numeric(paste0(substr(BOMDATE_AET_30, 1, 4),substr(BOMDATE_AET_30, 6, 7),substr(BOMDATE_AET_30, 9, 10),ifelse(substr(BOMDATE_AET_30, 12, 13)=="","00",substr(BOMDATE_AET_30, 12, 13)),"00"))

#Set up the data frame where all current recordings will be amalgamated
BOMgrid_df<-data.frame(matrix(NA,nrow=534,ncol=8))
colnames(BOMgrid_df)<-c("ID","YEAR","MONTH","DAY","HOUR","DATEID","TEMP","RAIN")

# #Bring in each BoM recording one at a time and write to BOMgrid_df
#Get date-time ranges (GMT) to extract bom data from the sense-t platform
GMTtime<-as.POSIXlt(Sys.time(), "GMT") #Sys.time()-(td*(60*60))
year<-substr(GMTtime, 1, 4)
month<-substr(GMTtime, 6, 7)
day<-substr(GMTtime, 9, 10)
hour<-ifelse(substr(GMTtime, 12, 13)=="","00",substr(GMTtime, 12, 13))
minute<-"30"
second<-"00"
st_time<-paste0(year,"-",month,"-",day,"T",hour,":",minute,":",second,".000Z")
en_time<-st_time

#Define GMT differentials
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==0){
  if(td==10){rng_time<-1}else{rng_time<-2}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==1){
  if(td==10){rng_time<-2}else{rng_time<-3}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==2){
  if(td==10){rng_time<-3}else{rng_time<-4}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==3){
  if(td==10){rng_time<-4}else{rng_time<-5}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==4){
  if(td==10){rng_time<-5}else{rng_time<-6}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==5){
  if(td==10){rng_time<-6}else{rng_time<-7}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==6){
  if(td==10){rng_time<-7}else{rng_time<-8}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==7){
  if(td==10){rng_time<-8}else{rng_time<-9}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==8){
  if(td==10){rng_time<-9}else{rng_time<-10}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==9){
  if(td==10){rng_time<-10}else{rng_time<-11}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==10){
  if(td==10){rng_time<-11}else{rng_time<-12}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==11){
  if(td==10){rng_time<-12}else{rng_time<-13}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==12){
  if(td==10){rng_time<-13}else{rng_time<-14}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==13){
  if(td==10){rng_time<-14}else{rng_time<-15}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==14){
  if(td==10){rng_time<-15}else{rng_time<-16}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==15){
  if(td==10){rng_time<-16}else{rng_time<-17}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==16){
  if(td==10){rng_time<-17}else{rng_time<-18}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==17){
  if(td==10){rng_time<-18}else{rng_time<-19}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==18){
  if(td==10){rng_time<-19}else{rng_time<-20}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==19){
  if(td==10){rng_time<-20}else{rng_time<-21}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==20){
  if(td==10){rng_time<-21}else{rng_time<-22}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==21){
  if(td==10){rng_time<-22}else{rng_time<-23}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==22){
  if(td==10){rng_time<-23}else{rng_time<-0}}
if(as.numeric(ifelse(substr(GMT, 12, 13)=="","00",substr(GMT, 12, 13)))==23){
  if(td==10){rng_time<-0}else{rng_time<-1}}

#Bring in each BoM recording one at a time and write to BOMgrid_df
setwd(INTERMEDIATE_LUT)
BOMLUT<-read.table ("BoM_LUT2.csv", sep=",", header=T)
for(i in 1:nrow(BOMLUT)){
  tryCatch({
    if(BOMLUT$State[i]=="TA"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDT60801/IDT60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="WA"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDW60801/IDW60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="NT"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDD60801/IDD60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="QL"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDQ60801/IDQ60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="NS"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDN60801/IDN60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="VI"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDV60801/IDV60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    if(BOMLUT$State[i]=="SA"){stn_dat<-read.csv(paste0("http://www.bom.gov.au/fwo/IDS60801/IDS60801.",BOMLUT$WMON[i],".axf"),skip = 19)}
    #closeAllConnections()
    for(j in 1:nrow(stn_dat)){
      if(stn_dat$aifstime_utc.80.[j]==BOMDATE_GMT*100){
        
        rng_time2<-GMT-(60*60*rng_time)
        rng_time2<-as.numeric(paste0(substr(rng_time2, 1, 4),substr(rng_time2, 6, 7),substr(rng_time2, 9, 10),ifelse(substr(rng_time2, 12, 13)=="","00",substr(rng_time2, 12, 13)),30))*100
        rng<-na.omit(stn_dat[stn_dat$aifstime_utc.80 > rng_time2, ]);rng<-rng[rng$aifstime_utc.80 <= BOMDATE_GMT*100, ]
        
        #BOMgrid_df$ID[i]<-BOMLUT$BOMID[i]
        acc_rn<-0
        if(nrow(rng)>1){for(k in nrow(rng):2){if(as.numeric(toString(rng$rain_trace.80.[k-1]))>as.numeric(toString(rng$rain_trace.80.[k]))){acc_rn<-acc_rn+(as.numeric(toString(rng$rain_trace.80.[k-1]))-as.numeric(toString(rng$rain_trace.80.[k])))}}}
        if((BOMDATE_AET*10000)==stn_dat$local_date_time_full.80.[j]){BOMgrid_df$RAIN[i]<-rng$rain_trace.80.[1]}else{BOMgrid_df$RAIN[i]<- acc_rn} 
        
        BOMgrid_df$ID[i]<-BOMLUT$BOMID[i]
        BOMgrid_df$TEMP[i]<-stn_dat$air_temp[j]
        BOMgrid_df$YEAR[i]<-substr(stn_dat$aifstime_utc.80.[j], 1, 4)
        BOMgrid_df$MONTH[i]<-substr(stn_dat$aifstime_utc.80.[j], 5, 6)
        BOMgrid_df$DAY[i]<-substr(stn_dat$aifstime_utc.80.[j], 7, 8)
        BOMgrid_df$HOUR[i]<-ifelse(substr(stn_dat$aifstime_utc.80.[j], 9, 10)=="3e"|substr(stn_dat$aifstime_utc.80.[j], 9, 10)=="","00",substr(stn_dat$aifstime_utc.80.[j], 9, 10))
        BOMgrid_df$DATEID[i]<-stn_dat$aifstime_utc.80.[j]/100
        break
      }
    }
  }, error=function(e){})
}
BOMLUT<-read.table ("BoM_LUT.csv", sep=",", header=T)

#Create the final BoM temps data frame
# BOMgrid_df<-na.omit(BOMgrid_df[which(BOMgrid_df$DATEID%in%freq$Var1[1]),])
BOMgrid_df<-na.omit(BOMgrid_df[which(BOMgrid_df$DATEID%in%BOMDATE_GMT),]);BOMgrid_df<-BOMgrid_df[which(BOMgrid_df$TEMP>-9999),]
BOM_temps<-BOMgrid_df[,c(1,7)]
colnames(BOM_temps)<-c("id","Temps")
BOM_rain<-BOMgrid_df[,c(1,8)]
colnames(BOM_rain)<-c("id","Rain")

#Test to ensure that this hour has not been already been processed by looking at the calibration file
setwd(INTERMEDIATE_CalibrationFiles_ADFD)
tryCatch({
  duptest<-read.table ("Calibration.csv", sep=",", header=T)
},error=function(e){print("Script initiated for the first time...")})
if(exists("duptest")==T){
  if(!is.na(duptest[nrow(duptest),1])){
    if(duptest[nrow(duptest),1]==BOMDATE_GMT){duptestTF<-T}else{duptestTF<-F}
  }
}else{duptestTF<-F}

#Check to see if nrow(BOM_temps) is equal or more than the last hour nrow(BOM_temps). 
# - If so proceed with mapping, otherwise wait until next import cyle.
setwd(INTERMEDIATE_LUT)
tryCatch({
  BoM_import_log<-read.table ("BoM_import_log.csv", sep=",", header=T)
},error=function(e){})
if(exists("BoM_import_log")==T){
  if(BoM_import_log[1,1]==BOMDATE_AET1hr){ifelse(BoM_import_log[1,2]>40,ImportNum<-BoM_import_log[1,2],ImportNum<-100)
  }else{ifelse(nrow(BOM_temps)>40,ImportNum<-nrow(BOM_temps),ImportNum<-100)}
} else{
  ifelse(nrow(BOM_temps)>40,ImportNum<-nrow(BOM_temps),ImportNum<-100)}

setwd(INTERMEDIATE_LUT)
tryCatch({
  BoM_import_log<-read.table ("BoM_import_log_rain.csv", sep=",", header=T)
},error=function(e){})
if(exists("BoM_import_log")==T){
  if(BoM_import_log[1,1]==BOMDATE_AET1hr){ifelse(BoM_import_log[1,2]>40,ImportNum<-BoM_import_log[1,2],ImportNum<-100)
  }else{ifelse(nrow(BOM_temps)>40,ImportNum<-nrow(BOM_temps),ImportNum<-100)}
} else{
  ifelse(nrow(BOM_temps)>40,ImportNum<-nrow(BOM_temps),ImportNum<-100)}

if((nrow(BOM_temps)>=480)&duptestTF==F){
  BoM_import_log<-data.frame(matrix(NA,nrow=1,ncol=2));colnames(BoM_import_log)<-c("BOMDATE_AET","ImportNum")
  BoM_import_log[1,1]<-BOMDATE_AET;BoM_import_log[1,2]<-nrow(BOM_temps)
  write.table(BoM_import_log ,file=paste0("BoM_import_log.csv"),col.names=T, row.names=F, append = F, quote = FALSE, sep=",")
  BoM_import_log<-data.frame(matrix(NA,nrow=1,ncol=2));colnames(BoM_import_log)<-c("BOMDATE_AET","ImportNum")
  BoM_import_log[1,1]<-BOMDATE_AET;BoM_import_log[1,2]<-nrow(BOM_temps)
  write.table(BoM_import_log ,file=paste0("BoM_import_log_rain.csv"),col.names=T, row.names=F, append = F, quote = FALSE, sep=",")
  
  ###########################################################################################################################################################################################################################
  ###Import the BoM covariate data#######################################################################################################
  ###########################################################################################################################################################################################################################
  
  #Import pre-establish BOM and LOGGER locations/covariates
  setwd(INTERMEDIATE_CovariateData_BOMLOG)
  BOM_XY_cov<-read.table ("BOM_XY_covariates.csv", sep=",", header=T);BOM_XY_cov$DEM<-round(BOM_XY_cov$DEM,1)

  #########################################################################################################################################################################################################################
  ###Import the Logger-BoMgrid coefficients and covariate stack############################################################################################################################################################
  #########################################################################################################################################################################################################################
  
  #Import covariates as a covariate stack
  setwd(INTERMEDIATE_CovariateData_TAS)  
  list.files(getwd(),  pattern="sdat$", full.names=FALSE)
  files<- list.files(getwd(), pattern='sdat$')
  r1<- raster(files[1])
  
  #########################################################################################################################################################################################################################
  ###MODELLING#############################################################################################################################################################################################################
  #########################################################################################################################################################################################################################
  
  #Create the training datasets in preperation for mapping
  BOM_temps_cov<-merge(x=BOM_temps,y=BOM_XY_cov,by="id",all.x=T)
  BOM_temps_cov<-BOM_temps_cov[,c(1,3,4,2,5:ncol(BOM_temps_cov))]; colnames(BOM_temps_cov)[1:4]<-c("ID","X","Y","Temps")

  TrainingData<-BOM_temps_cov
  TrainingData<-na.omit(TrainingData);TrainingData<-TrainingData[!duplicated(TrainingData),]
  
  BOM_temps_cov_r<-merge(x=BOM_rain,y=BOM_XY_cov,by="id",all.x=T)
  BOM_temps_cov_r<-BOM_temps_cov_r[,c(1,3,4,2,5:ncol(BOM_temps_cov_r))]; colnames(BOM_temps_cov_r)[1:4]<-c("ID","X","Y","Rain")

  TrainingData_r<-BOM_temps_cov_r
  TrainingData_r<-na.omit(TrainingData_r);TrainingData_r<-TrainingData_r[!duplicated(TrainingData_r),]
  
  dir.create(paste(ROOT_DIR,"/temp",sep=""));rasterOptions(tmpdir=paste(ROOT_DIR,"/temp",sep=""))	
  
  #Create the TPS functions
  grid_t<- data.frame(TrainingData[,c(2:4,5)])
  tp_e<- Tps( coordinates(grid_t[,1:2]), grid_t$Temps, Z= grid_t$DEM)
  
  pfun <- function(model, x, ...) {
    predict(model, x[,1:2], Z=x[,3], ...)
  }
  
  grid_t_r<- data.frame(TrainingData_r[,c(2:4)])
  tp_e_r<- Tps( coordinates(grid_t_r[,1:2]), grid_t_r$Rain)
  
  pfun_r <- function(model, x, ...) {
    predict(model, x[,1:2], ...)
  }
  rfallSum<-sum(grid_t_r$Rain)
  
  #########################################################################################################################################################################################################################
  ###MAPPING###############################################################################################################################################################################################################
  #########################################################################################################################################################################################################################
  print("Conducting mapping of temperatures...")
  setwd(INPUT_StudyAreas)
  kmlfiles <-list.files()
  kml_len<-length(kmlfiles);if(kml_len==0){kmlfiles<-"TAS.kml"}
  for(k in kmlfiles){
    
    #Import KML file - reproject to UTM
    if(k!="TAS.kml"){
      setwd(INPUT_StudyAreas)
      layer_nam<-ogrListLayers(dsn=k)[1]
      kml<-readOGR(dsn=k,layer_nam)
      kml<-spTransform(kml,CRS="+proj=utm +zone=55 +south +datum=WGS84")
    }
    
    #Create study area directory if it does not already exist
    SareaNam<-gsub(".kml","",k)
    if(file.exists(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam))==F){
      dir.create(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam))
      dir.create(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam,"tif"))
      dir.create(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam,"ncdf"))}
    
    #Crop covariate stack to the study area extent if it is NOT TAS.kml
    if(k=="TAS.kml"){
      covstack<-r1
    }else{
      if(file.exists(file.path(INTERMEDIATE_CovariateData_StudyAreas,SareaNam))==F){
        print("Snapping covariates to study area for the first time...")
        dir.create(file.path(INTERMEDIATE_CovariateData_StudyAreas,SareaNam))
        setwd(file.path(INTERMEDIATE_CovariateData_StudyAreas,SareaNam))
        covstack<-crop(r1,kml)
        for(i in 1:nlayers(covstack)){writeRaster(rasterize(kml, eval(parse(text=paste0("covstack$",names(covstack)[i]))), mask=TRUE), filename=paste0(names(covstack)[i],".tif"), "GTiff", overwrite=TRUE)}
        files<- list.files(getwd(), pattern='tif$')
        covstack<- raster(files[1])
        for(i in 2:length(files)){
          covstack<- stack(covstack,files[i])} 
      }else{ #If covariates already exist for study area
        setwd(file.path(INTERMEDIATE_CovariateData_StudyAreas,SareaNam))
        files<- list.files(getwd(), pattern='tif$')
        covstack<- raster(files[1])
        for(i in 2:length(files)){
          covstack<- stack(covstack,files[i])} 
      }
    }
    grid_v <- covstack$DEM
    #Spatially predict the temperatures across the study area covariate space and write to tiff
    setwd(file.path(OUTPUT_TemperatureMapping_LIVE,SareaNam,"tif"))
    maxpred<-max(TrainingData$Temp)+((max(TrainingData$Temp)-min(TrainingData$Temp))*0.1);minpred<-min(TrainingData$Temp)-((max(TrainingData$Temp)-min(TrainingData$Temp))*0.1)
    beginCluster(detectCores()-2)
    spatial_prediction_Map <- clusterR(grid_v, interpolate, args=list(model=tp_e, xyOnly=FALSE,fun=pfun),filename= paste0("TempPrediction_",BOMDATE_AET,AET_str,".tif"),format="GTiff",progress="text",overwrite=T)
    writeRaster(round(spatial_prediction_Map,1), paste0("TempPrediction_",BOMDATE_AET,AET_str,".tif"),format="GTiff",progress="text",overwrite=T)

    setwd(file.path(OUTPUT_RainfallMapping_LIVE,SareaNam,"tif"))
    if(rfallSum<1){
      endCluster()
      spatial_prediction_Map_r<-spatial_prediction_Map*0
      writeRaster(spatial_prediction_Map_r, paste0("RainPrediction_",BOMDATE_AET,AET_str,".tif"),format="GTiff",progress="text",overwrite=T,datatype="INT2S")
    } else{
      spatial_prediction_Map_r <- clusterR(grid_v, interpolate, args=list(model=tp_e_r, xyOnly=FALSE,fun=pfun_r),filename= paste0("RainPrediction_",BOMDATE_AET,AET_str,".tif"),format="GTiff",progress="text",overwrite=T,datatype="INT2S")
      endCluster()
      minpred<-0
      spatial_prediction_Map_r[spatial_prediction_Map_r<minpred]<-minpred
      writeRaster(spatial_prediction_Map_r, paste0("RainPrediction_",BOMDATE_AET,AET_str,".tif"),format="GTiff",progress="text",overwrite=T,datatype="INT1U")
    }
  }
  setwd(ROOT_DIR);unlink("temp", recursive = TRUE, force = TRUE)
  
  print("Updating calibration files...")
  
  #########################################################################################################################################################################################################################
  ###Attach the new predictions to the ADFD calibration table##############################################################################################################################################################
  #########################################################################################################################################################################################################################
  
  #Check if ADFD calibration files exists (i.e. Is this the first time this script has been executed???)
  setwd(INTERMEDIATE_CalibrationFiles_ADFD)
  tryCatch({
    test<-read.table ("Calibration.csv", sep=",", header=T)
  },error=function(e){print("Script initiated for the first time...creating the initial ADFD calibration file")})
  
  #If calibration file does not exist, create it...
  if(exists("test")==F){
    AllTemps_t <- t(TrainingData[,c(1,4)])
    Calibration<-data.frame(matrix(NA,ncol=ncol(AllTemps_t)+1,nrow=1));colnames(Calibration)<-c("DATEID",AllTemps_t[1,])
    Calibration$DATEID[1]<-BOMDATE_GMT;Calibration[1,2:ncol(Calibration)]<-AllTemps_t[2,1:ncol(AllTemps_t)]
    setwd(INTERMEDIATE_CalibrationFiles_ADFD)
    write.table(Calibration ,file=paste0("Calibration.csv"),col.names=T, row.names=F, append = F, quote = FALSE, sep=",")
  }
  
  #If calibration file does exist, append the new live temp predictions to the existing one.
  if(exists("test")==T){
    #Import the calibration table and produce data frame with the column names
    setwd(INTERMEDIATE_CalibrationFiles_ADFD)
    Calibration <- read.table("Calibration.csv", header=TRUE, sep=",",check.names = F)
    if(nrow(Calibration)>1440){Calibration<-Calibration[(nrow(Calibration)-1440):(nrow(Calibration)),]}
    
    #Merge the Original training data to the ADFD calibration table and write to file
    AllTemps <- TrainingData[,c(1,4)];AllTemps_t<-t(AllTemps);AllTemps_t<-data.frame(AllTemps_t);colnames(AllTemps_t)<-as.numeric(AllTemps_t[1,]);AllTemps_t<-AllTemps_t[-1,]
    Calibration1<-rbind.fill(Calibration,AllTemps_t);Calibration1[nrow(Calibration1),1]<-BOMDATE_GMT;Calibration1<-Calibration1[!duplicated(Calibration1$DATEID),]
    write.table(Calibration1 ,file=paste0("Calibration.csv"),col.names=T, row.names=F, append = F, quote = FALSE, sep=",")
  }
  
  if(GEOSERVER=="y"){
    # IF GEOSERVER IS INSTALLED AND OPERATING
    GeoTIFF_name<-paste0("TempPrediction_",BOMDATE_AET,AET_str)
    GeoTIFF_path<-paste0(OUTPUT_TemperatureMapping_LIVE,"/",SareaNam,"/tif/")
    
    system(paste('curl -f -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/plain" -d "',
                 GeoTIFF_path,GeoTIFF_name,".tif",'" "',
                 GeoServer_url,"/rest/workspaces/",GeoServer_workspace_name,"/coveragestores/",GeoTIFF_name,"/external.geotiff",'"',sep=""))
    
    system(paste('curl -f -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/xml" -d "<coverage><srs>',CoordSysCode,'</srs><enabled>true</enabled></coverage>" "',
                 GeoServer_url,"/rest/workspaces/",GeoServer_workspace_name,"/coveragestores/",GeoTIFF_name,"/coverages/",GeoTIFF_name,'"',sep=""))
    
    system(paste('curl -s -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/xml" -d "<layer><name>',
                 GeoTIFF_name,'</name><defaultStyle><name>',GeoServer_workspace_name,':',Style_name,
                 '</name></defaultStyle></layer>" "',GeoServer_url,'/rest/layers/',GeoServer_workspace_name,':',GeoTIFF_name,'"',sep=""))
    
    tifnames<-list.files(GeoTIFF_path)
    tifnames_df<-data.frame(matrix(NA,nrow=length(tifnames),ncol=1));colnames(tifnames_df)<-"datetime"
    for(r in 1:length(tifnames)){tifnames_df[r,]<-as.numeric(gsub("[^\\d]+", "", tifnames[r], perl=TRUE))}#20191025
    if(length(tifnames)>6){
      tifnames_df<-tifnames_df[order(-tifnames_df$datetime),];tifnames_df<-tifnames_df[7:length(tifnames_df)]
      for(r in 1:length(tifnames_df)){
        system(paste('curl -s -o /dev/null -k -u ',UN,':',PW,' -XDELETE "',
                     GeoServer_url,'/rest/workspaces/',GeoServer_workspace_name,'/coveragestores/',paste0("TempPrediction_",tifnames_df[r],AET_str),'?recurse=true"',sep=""))
      }
    }
    
    tifnames<-list.files(GeoTIFF_path)
    tifnames_df<-data.frame(matrix(NA,nrow=length(tifnames),ncol=1));colnames(tifnames_df)<-"datetime"
    for(r in 1:length(tifnames)){tifnames_df[r,]<-as.numeric(gsub("[^\\d]+", "", tifnames[r], perl=TRUE))}#20191025
    tifnames_df<-tifnames_df[order(-tifnames_df$datetime),];tifnames_df<-tifnames_df[1:6]
    
    
    #Rainfall
    GeoTIFF_name<-paste0("RainPrediction_",BOMDATE_AET,AET_str)
    GeoTIFF_path<-paste0(OUTPUT_RainfallMapping_LIVE,"/",SareaNam,"/tif/")
    
    system(paste('curl -f -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/plain" -d "',
                 GeoTIFF_path,GeoTIFF_name,".tif",'" "',
                 GeoServer_url,"/rest/workspaces/",GeoServer_workspace_name2,"/coveragestores/",GeoTIFF_name,"/external.geotiff",'"',sep=""))
    
    system(paste('curl -f -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/xml" -d "<coverage><srs>',CoordSysCode,'</srs><enabled>true</enabled></coverage>" "',
                 GeoServer_url,"/rest/workspaces/",GeoServer_workspace_name2,"/coveragestores/",GeoTIFF_name,"/coverages/",GeoTIFF_name,'"',sep=""))
    
    system(paste('curl -s -k  -u ',UN,':',PW,' -XPUT -H "Content-type: text/xml" -d "<layer><name>',
                 GeoTIFF_name,'</name><defaultStyle><name>',GeoServer_workspace_name2,':',Style_name2,
                 '</name></defaultStyle></layer>" "',GeoServer_url,'/rest/layers/',GeoServer_workspace_name2,':',GeoTIFF_name,'"',sep=""))
    
    tifnames<-list.files(GeoTIFF_path)
    tifnames_df<-data.frame(matrix(NA,nrow=length(tifnames),ncol=1));colnames(tifnames_df)<-"datetime"
    for(r in 1:length(tifnames)){tifnames_df[r,]<-as.numeric(gsub("[^\\d]+", "", tifnames[r], perl=TRUE))}#20191025
    if(length(tifnames)>6){
      tifnames_df<-tifnames_df[order(-tifnames_df$datetime),];tifnames_df<-tifnames_df[7:length(tifnames_df)]
      for(r in 1:length(tifnames_df)){
        system(paste('curl -s -o /dev/null -k -u ',UN,':',PW,' -XDELETE "',
                     GeoServer_url,'/rest/workspaces/',GeoServer_workspace_name2,'/coveragestores/',paste0("RainPrediction_",tifnames_df[r],AET_str),'?recurse=true"',sep=""))
      }
    }
    
    
    # IF RSTUDIO SERVER WITH SHINY IS INSTALLED AND OPERATING 
    ###20181228###
    tifnames<-list.files(GeoTIFF_path)
    tifnames_df<-data.frame(matrix(NA,nrow=length(tifnames),ncol=1));colnames(tifnames_df)<-"datetime"
    for(r in 1:length(tifnames)){tifnames_df[r,]<-as.numeric(gsub("[^\\d]+", "", tifnames[r], perl=TRUE))}#20191025
    tifnames_df<-tifnames_df[order(-tifnames_df$datetime),];tifnames_df<-tifnames_df[1:6]
    
    if(require("leaflet")){
      print("leaflet is loaded correctly")
    } else {
      print("trying to install leaflet")
      install.packages("leaflet")
      if(require("leaflet")){
        print("leaflet installed and loaded")
      } else {
        stop("could not install leaflet")
      }
    }
    if(require("htmlwidgets")){
      print("htmlwidgets is loaded correctly")
    } else {
      print("trying to install htmlwidgets")
      install.packages("htmlwidgets")
      if(require("htmlwidgets")){
        print("htmlwidgets installed and loaded")
      } else {
        stop("could not install htmlwidgets")
      }
    }
    if(require("leaflet.extras")){
      print("leaflet.extras is loaded correctly")
    } else {
      print("trying to install leaflet.extras")
      install.packages("leaflet.extras")
      if(require("leaflet.extras")){
        print("leaflet.extras installed and loaded")
      } else {
        stop("could not install leaflet.extras")
      }
    }
    if(require("leaflet.esri")){
      print("leaflet.esri is loaded correctly")
    } else {
      print("trying to install leaflet.esri")
      install.packages("leaflet.esri")
      if(require("leaflet.esri")){
        print("leaflet.esri installed and loaded")
      } else {
        stop("could not install leaflet.esri")
      }
    }
    
    #Set up BoM/Sensor locations to display current temperatures with associate web links
    setwd(INTERMEDIATE_LUT)
    BoM_temps2<-cbind(BOM_temps,BOM_rain$Rain);colnames(BoM_temps2)[3]<-"Rain";colnames(BoM_temps2)[1]<-"BOMID"
    BoM_temps2<-merge(x=BoM_temps2, y=BOMLUT, by="BOMID",all.x=T)
    BoM_temps2[,5]<-NA;colnames(BoM_temps2)[5]<-"URL";colnames(BoM_temps2)[1]<-"ID"
    BOMLUT<-read.table ("BoM_LUT2.csv", sep=",", header=T);colnames(BOMLUT)[2]<-"ID"
    BoM_temps2_mer<-merge(x=BoM_temps2,y=BOMLUT,by="ID",all.x=T)
    
    for(r in 1:nrow(BoM_temps2)){
      if(BoM_temps2_mer$State[r]=="TA"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDT60801/IDT60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="WA"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDW60801/IDW60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="NT"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDD60801/IDD60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="QL"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDQ60801/IDQ60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="NS"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDN60801/IDN60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="VI"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDV60801/IDV60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
      if(BoM_temps2_mer$State[r]=="SA"){BoM_temps2[r,5]<-paste0("<b><a href='http://www.bom.gov.au/products/IDS60801/IDS60801.",BoM_temps2_mer$WMON.x[r],".shtml'target=_blank/a></b>")}
    }
    BoM_temps3<-merge(x=BoM_temps2, y=BOM_temps_cov, by="ID",all.x=T)
    BoM_temps3<-BoM_temps3[,which(colnames(BoM_temps3)%in%c("ID","X","Y","Temps.x","Rain","URL"))];colnames(BoM_temps3)<-c("ID","Temperature","Rain","URL","X","Y")
    coords<- SpatialPoints(BoM_temps3[,c("X","Y")],proj4string = CRS("+proj=lcc +lat_1=-18 +lat_2=-36 +lat_0=0 +lon_0=134 +x_0=0 +y_0=0 +ellps=GRS80 +towgs84=0,0,0,0,0,0,0 +units=m +no_defs"))
    LATLONG<-data.frame(spTransform(coords,CRS="+proj=longlat +datum=WGS84"));colnames(LATLONG)<-c("Long","Lat")
    BoM_temps3<-cbind(BoM_temps3,LATLONG);BOMAWS_temps<-BoM_temps3
    
    temprg<-seq(-5,40,1)
    temppal <- colorNumeric(c("#4a001d","#4a001d","#31007e","#31007e","#000081","#0032b3",
                              "#0032b3","#0000ff","#0000ff","#007dff","#00bdff","#00bdff","#17d78b","#17d78b","#39ad73",
                              "#2aa92a","#2aa92a","#2ac82a","#2ac82a","#00ff31","#53ff00","#53ff00","#9fff00","#9fff00","#ffff00",
                              "#ffff00","#ffcc00","#ff9800","#ff9800","#ff6500","#ff6500","#ff5400","#ff0000","#ff0000","#ff007f",
                              "#ff007f","#ff2290","#ff5eb1","#ff86c2","#ff86c2","#ffaed7","#ffd7eb","#ffd7eb","#ffffff","#ffffff"), temprg,na.color = "transparent")
    
    
    rainrg<-seq(0,40,2)
    rainpal <- colorNumeric(c("#ffffff","#d1920f","#f0db05","#ccff00","#66ff00","#00ff00","#14e633","#28cc66","#3cb399","#509acc",
                              "#6480ff","#5066ff","#3c4dff","#2833ff","#1419ff","#0000ff","#1900ff","#3300ff","#4d00ff","#6600ff"), rainrg,na.color = "transparent")
    rainrg2<-seq(40,80,2)
    rainpal2 <- colorNumeric(c("#8000ff","#9a00ff","#b300ff","#cc00ff","#e600ff","#ff00ff","#ff00f5","#ff00eb","#ff00e1","#ff00d7",
                               "#ff00cc","#ff00c2","#ff00b8","#ff00ae","#ff00a3","#ff0099","#ff008f","#ff0085","#ff007a","#ff0070"), rainrg2,na.color = "transparent")
    
    #Set up date and time components for map legends
    YR<-paste0(substr(TasLT, 1, 4));MN<-paste0(substr(TasLT, 6, 7));DY<-paste0(substr(TasLT, 9, 10));HR<-as.numeric(ifelse(substr(TasLT, 12, 13)=="",0,substr(TasLT, 12, 13)))
    if(HR==0){HR<-"12:30AM"};if(HR%in%c(1:11)){HR<-paste0(HR,":30AM")};if(HR==12){HR<-paste0(HR,":30PM")};if(HR==13){HR<-paste0(1,":30PM")};if(HR==14){HR<-paste0(2,":30PM")};
    if(HR==15){HR<-paste0(3,":30PM")};if(HR==16){HR<-paste0(4,":30PM")};if(HR==17){HR<-paste0(5,":30PM")};if(HR==18){HR<-paste0(6,":30PM")};if(HR==19){HR<-paste0(7,":30PM")};if(HR==20){HR<-paste0(8,":30PM")};
    if(HR==21){HR<-paste0(9,":30PM")};if(HR==22){HR<-paste0(10,":30PM")};if(HR==23){HR<-paste0(11,":30PM")}
    
    print("Printing out shiny app data")
    save.image(paste0(INTERMEDIATE_LUT,"/shiny_app_data.RData"))
  }

  print(paste0("Near live Temperature mapping complete for ",BOMDATE_AET,AET_str))
  deltemp<-list.files(paste0(tempdir(),"\\raster"))
  for(d in 1:length(deltemp)){unlink(paste0(tempdir(),"\\raster\\",deltemp[d]),force=T,recursive = T)}
} else{
  if(duptestTF==T){print("Mapping has already been conducted for the hour")}else{print("Insufficent BoM recordings")}
}
###END OF SCRIPT####
